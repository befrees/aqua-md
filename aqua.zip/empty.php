<!DOCTYPE html>
<html lang="en">
<head>
	<?php include 'parts/_head.php' ?>
</head>
<body>
	<div id="wrapper" class="wrapper">
        <?php include 'parts/header.php'; ?>
		<div class="middle">
			<div class="container">
				
			</div>
		</div>
    </div>
    <?php include 'parts/footer.php' ?>
</body>
</html>