<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
</head>
<body>
	<ol>
		<li><a href="home.php">Home</a></li>
		<!-- <li><a href="company.php">Страница компании</a> Работают табы и таймер</li> -->
		<li><h4>Catalog</h4>
			<ol>
				<li><a href="all-categories.php">All categories</a></li>
				<li><a href="category-1.php">Category 1</a></li>
				<!-- <li><a href="catalog-1-2.php">Catalog 1 / 2</a></li> -->
				<!-- <li><a href="catalog-1-3.php">Catalog 1 / 3</a></li> -->
				<li><a href="catalog-grid.php">Catalog grid</a></li>
				<li><a href="catalog-list.php">Catalog list</a></li>
				<!-- <li><a href="search.php?s=Набор+смесителей">Результаты поиска</a></li> -->
			</ol>
		</li>
		<li><h4>Товар</h4>
			<ol>
				<li><a href="goods-one.php">Товар в наличии</a> Кликабельны табы, "купить по телефону", "купить"</li>
				<li><a href="goods-one-2.php">Товар в наличии [promo code]</a></li>
				<li><a href="goods-one-access.php">Товар в наличии [ламинат]</a></li>
				<li><a href="goods-one-dis-1.php">Товар нет в нличии</a></li>
				<li><a href="goods-one-dis-2.php">Товар снят с производства</a></li>

				<!-- 
				<li><a href="goods-one-gift.php">Товар с подарком</a></li>
				<li><a href="goods-one-discontinued.php">Товар снят с производства</a></li> -->
			</ol>
		</li>
		<li><h4>Корзина</h4>
			<ol>
				<!-- <li><a href="cart-1.php">Корзина шаг 1</a></li>
				<li><a href="cart-2.php">Корзина шаг 2</a></li> -->
			</ol>
		</li>
		<li><h4>Кабинет</h4>
			<ol>
				<!-- <li><a href="account-1.php">Кабинет 1 (личные данные)</a></li>
				<li><a href="account-2.php">Кабинет 2 (редактирование личных данных)</a></li>
				<li><a href="account-3.php">Кабинет 3 (редактирование пароля)</a></li>
				<li><a href="account-order-1.php">Кабинет - отследить заказ</a> Стрелка открытия кликабельна</li>
				<li><a href="account-wishlist.php">Кабинет - Списки желаний</a> "Добавить новый список" кликабельна</li>
				<li><a href="account-waiting.php">Кабинет - Список ожидания</a></li>
				<li><a href="account-recent_goods.php">Кабинет - Просмотренные товары</a></li>
				<li><a href="account-feedback.php">Кабинет - Мои отзывы</a></li>
				<li><a href="account-feedback-empty.php">Кабинет - Мои отзывы (пусто)</a></li> -->
			</ol>
		</li>
		<li><h4>Страницы</h4>
			<ol>
				<!-- <li><a href="blog.php">Blog list</a></li>
				<li><a href="blog-single.php">Blog single</a></li>
				<li><a href="faq.php">FAQ</a></li>
				<li><a href="complaint.php">Жалоба</a></li>
				<li><a href="careers.php">Вакансии</a></li>
				<li><a href="credit.php">Кредит</a></li>
				<li><a href="contact.php">Контакты</a></li>
				<li><a href="delivery.php">Доставка и оплата</a></li>
				<li><a href="brands.php">Торговые марки</a></li> -->
			</ol>
		</li>
		<li><a href="aqua.zip">Скачать архив</a></li>
	</ol>
</body>
</html>
