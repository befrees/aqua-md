<div class="container">
        			<div class="row slider-brands-wrap">
        				<div class="slider-catalog-brands">
        					<div class="slide-item"><a href="#"><img src="img/baner-rekl-1.png" alt=""></a></div>
        					<div class="slide-item"><a href="#"><img src="img/baner-rekl-1.png" alt=""></a></div>
        					<div class="slide-item"><a href="#"><img src="img/baner-rekl-1.png" alt=""></a></div>
        					<div class="slide-item"><a href="#"><img src="img/baner-rekl-1.png" alt=""></a></div>
        				</div>
        			</div>
        		</div>