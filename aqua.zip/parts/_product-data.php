<div class="data-bottom cf">
                                <div class="col-sm-4 data-bottom-col">
                                    <div class="h3"><i class="ic icon-ic-car-1"></i>Доставка по Харькову</div>
                                    <div class="text">
                                        <ul>
                                            <li>самовывоз с магазина</li>
                                            <li>бесплатно от 5500 грн <a href="#">(подробней)</a></li>
                                            <li>оплатить можно наличными</li>
                                            <li>картой VISA или MasterCard</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-sm-4 data-bottom-col">
                                    <div class="h3"><i class="ic icon-ic-ukr"></i>Доставка по Украине</div>
                                    <div class="text">
                                        <ul>
                                            <li>от 35 грн <a href="#">(уточнить стоимость)</a></li>
                                            <li>от одного до трех дней</li>
                                            <li>оплатить можно наличными</li>
                                            <li>картой VISA или MasterCard</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-sm-4 data-bottom-col">
                                    <div class="h3"><i class="ic icon-ic-secur"></i>Гарантия</div>
                                    <div class="text">
                                        <ul>
                                            <li>официальная гарантия от производителя
                                            </li>
                                            <li>обмен/возврат товара в течение 14 дней</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>