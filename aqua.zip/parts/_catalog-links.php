
<div class="catalog-drop container cf">
	<div class="row catalog-drop-inner">
	<ul class="menu-catalog-drop">
		<li class="level-1 hover">
			<a href="#"><i class="ic icon-ic--bathroom"></i><span class="">Ванная комната</span></a>
			
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic-plumbing"></i><span class="">Водопровод</span></a>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic-watering"></i><span class="">Полив</span></a>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic-tile"></i><span class="">Плитка</span></a>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic-filter"></i><span class="">Фильтры</span></a>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic-heating"></i><span class="">Отопление</span></a>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic--kitchen"></i><span class="">Кухня</span></a>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic-accessories"></i><span class="">Аксессуары</span></a></span>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="level-1">
			<a href="#"><i class="ic icon-ic-specialplumbing"></i><span class="">Специальная  Сантехника</span></a>
			<ul class="menu col col_sub-menu">
				<li>
					<a href="#">Анти-накипальтельные фильтры для бытовой техники</a>
					<ul class="sub-menu col">
						<li><a href="#">Проточные фильтры</a></li>
						<li><a href="#">Системы обратного осмоса</a></li>
						<li><a href="#">Фильтры кувшины</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Системы умягчения и комплексной очистки</a>
					<ul class="sub-menu col">
						<li><a href="#">Гидромассажные системы</a></li>
						<li><a href="#">Гидромассажные системы</a></li>
					</ul>
				</li>
				<li>
					<a href="#">Сменные элементы и комплектующие</a>
					<ul class="sub-menu col">
						<li><a href="#">Принятие душа</a></li>
						<li><a href="#">Принятие ванны</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li class="col offer-col-li">
			<div class="col-offer">
				<div class="h3">ПРЕДЛОЖЕНИЕ НЕДЕЛИ</div>
				
<div class="goods-item">
	<div class="box-goods">
		<div class="inner-goods cf">
			<div class="goods-image">
				<figure class="image">
					<a href="#"><img src="img/products/image-011.png" alt=""></a>
				</figure> <!-- .image -->
			</div>
			<div class="goods-data">
				<div class="text-danger text-uppercase info">СУПЕРЦЕНА!</div>
				<div class="name"><a href="#">Дозатор жидкого мыла GROHE 
ESSENTIALS 40394001</a></div>
				<div class="flexbox goods-top-data border">
					<div class="prices price-black">
						<div class="price">8 333 <span class="currency">грн.</span></div>
					</div>
				</div>
			</div>

			
		</div>
	</div>
</div>
			</div>
		</li>
	</ul> <!-- .menu-catalog-drop -->
</div>
</div> <!-- .catalog-drop -->

