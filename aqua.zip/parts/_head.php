<?php include './src/goods.php' ?>
<meta charset="UTF-8">
    <title>AQUA KHARKOV</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
